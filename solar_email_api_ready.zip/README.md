# Solar ROI API (Horizon)

## שימוש:
- מקבל נתוני מערכת סולארית (POST)
- מחשב תשואה
- יוצר PDF
- שולח לכתובת מייל

## פריסה ל-Render:
1. העלה את התיקייה הזו לריפו ב-GitHub
2. התחבר ל-render.com ובחר New Web Service
3. Start command: `python app.py`
4. Environment Variables:
    - EMAIL_USER = your@gmail.com
    - EMAIL_PASS = סיסמת אפליקציה (App Password מגוגל)